# Align []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/align.md)

Use `align`, `halign` and `valign` options to set the alignment of the columns and their header. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/17/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>
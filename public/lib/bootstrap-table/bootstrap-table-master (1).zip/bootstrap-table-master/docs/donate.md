---
layout: default
title: pages.donate.title
slug: donate
lead: pages.donate.lead
---

{% tf donate.md %}

<div class="row">
    <div class="col-md-6">
        <div class="tc">
            <img src="../assets/images/alipayLogo.png">
        </div>
        <div class="tc">
            <img src="../assets/images/alipay.jpg">
        </div>
    </div>
    <div class="col-md-6">
        <div class="tc">
            <img src="../assets/images/paypalLogo.png">
        </div>
        <div class="tc">
            <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZDHP676FQDUT6">
                <img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif">
            </a>
        </div>
    </div>
</div>